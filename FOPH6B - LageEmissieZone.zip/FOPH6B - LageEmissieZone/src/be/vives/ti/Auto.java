package be.vives.ti;

import java.util.Objects;

public class Auto {
    private String nummerplaat;
    private String merk;
    private String kleur;
    private int euronorm;
    private Brandstof brandstof;

    public Auto(String nummerplaat, String merk, String kleur, int euronorm, Brandstof brandstof) {
        this.nummerplaat = nummerplaat;
        this.merk = merk;
        this.kleur = kleur;
        this.euronorm = euronorm;
        this.brandstof = brandstof;
    }

    public String getNummerplaat() {
        return nummerplaat;
    }

    public String getMerk() {
        return merk;
    }

    public String getKleur() {
        return kleur;
    }

    public int getEuronorm() {
        return euronorm;
    }

    public Brandstof getBrandstof() {
        return brandstof;
    }

    @Override
    public String toString() {
        return "Auto{" +
                "nummerplaat='" + nummerplaat + '\'' +
                ", merk='" + merk + '\'' +
                ", kleur='" + kleur + '\'' +
                ", euronorm=" + euronorm +
                ", brandstof=" + brandstof +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Auto)) return false;
        Auto auto = (Auto) o;
        return nummerplaat.equals(auto.nummerplaat);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nummerplaat);
    }
}