package be.vives.ti;

public class Main {

    public static void main(String[] args) {
        Auto auto1 = new Auto("1-DBE-402", "Audi", "Zwart", 6, Brandstof.DIEZEL);
        Auto auto2 = new Auto("1-ADP-068", "Volkswagen", "Rood", 4, Brandstof.ELEKTRISCH);
        Auto auto3 = new Auto("1-PDN-703", "Audi", "Zwart", 1, Brandstof.BENZINE);
        Auto auto4 = new Auto("1-END-652", "BMW", "Blauw", 3, Brandstof.DIEZEL);
        Auto auto5 = new Auto("1-MQE-743", "Opel", "Wit", 2, Brandstof.BENZINE);
        Auto auto6 = new Auto("1-NDI-480", "Volkswagen", "Zwart", 4, Brandstof.DIEZEL);
        Auto auto7 = new Auto("1-ANC-663", "Ford", "Blauw", 6, Brandstof.BENZINE);

        LezChecker lezChecker = new LezChecker();
        lezChecker.inschrijvenAuto(auto1);
        lezChecker.inschrijvenAuto(auto2);
        lezChecker.inschrijvenAuto(auto3);
        lezChecker.inschrijvenAuto(auto4);
        lezChecker.inschrijvenAuto(auto5);
        lezChecker.inschrijvenAuto(auto6);
        lezChecker.inschrijvenAuto(auto7);

        System.out.println(lezChecker.controleerLezAntwerpen(auto1.getNummerplaat()));
        System.out.println(lezChecker.controleerLezAntwerpen(auto2.getNummerplaat()));
        System.out.println(lezChecker.controleerLezAntwerpen(auto3.getNummerplaat()));
        System.out.println(lezChecker.controleerLezAntwerpen(auto4.getNummerplaat()));
        System.out.println(lezChecker.controleerLezAntwerpen(auto5.getNummerplaat()));
        System.out.println(lezChecker.controleerLezAntwerpen(auto6.getNummerplaat()));
        System.out.println(lezChecker.controleerLezAntwerpen(auto7.getNummerplaat()));

        System.out.println("----");
        lezChecker.uitschrijvenAuto(auto4.getNummerplaat());
        System.out.println(lezChecker.controleerLezAntwerpen(auto4.getNummerplaat()));
    }
}
