package be.vives.ti;

public enum LezCode {
    GROEN ("Toegang"),
    ORANJE ("Toegang na betaling"),
    ROOD ("Toegang met LEZ-dagpas"),
    ONBEKEND ("Geen informatie bekend over de wagen");

    private String omschrijving;

    LezCode(String omschrijving) {
        this.omschrijving = omschrijving;
    }

    public String toString() {
        return omschrijving;
    }
}
