package be.vives.ti;

import java.util.HashMap;

public class LezChecker {
    private HashMap<String, Auto> ingeschrevenAutos;

    public LezChecker() {
        this.ingeschrevenAutos = new HashMap<>();
    }

    public void inschrijvenAuto(Auto auto) {
        ingeschrevenAutos.put(auto.getNummerplaat(), auto);
    }

    public void uitschrijvenAuto(String nummerplaat) {
        ingeschrevenAutos.remove(nummerplaat);
    }

    public LezCode controleerLezAntwerpen(String nummerplaat) {
        LezCode output = null;
        Auto auto = ingeschrevenAutos.get(nummerplaat);
        if (auto != null) {
            if (Brandstof.DIEZEL.equals(auto.getBrandstof())) {
                if (auto.getEuronorm() >= 5) {
                    output = LezCode.GROEN;
                }
                if (auto.getEuronorm() == 4) {
                    output = LezCode.ORANJE;
                }
                if (auto.getEuronorm() <= 3) {
                    output = LezCode.ROOD;
                }
            } else {
                if (Brandstof.BENZINE.equals(auto.getBrandstof())) {
                    if (auto.getEuronorm() > 1) {
                        output = LezCode.GROEN;
                    } else {
                        output = LezCode.ROOD;
                    }
                }
                else {
                    output = LezCode.ONBEKEND;
                }
            }
        }
        else {
            output = LezCode.ONBEKEND;
        }
        return output;
    }
}
