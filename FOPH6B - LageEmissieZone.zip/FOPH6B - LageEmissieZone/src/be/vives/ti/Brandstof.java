package be.vives.ti;

public enum Brandstof {
    DIEZEL,
    BENZINE,
    ELEKTRISCH;
}
