package be.vives.ti;

public class Weiland extends Perceel{
    private static final double ONDERHOUDWEILAND = 250; // euro/hectare
    private static final double HOEVEELHEID_MELK = 10; // liter melk/dag/koe
    private static final int DAGEN_PER_JAAR = 200; // dagen/jaar
    private static double melkPrijs = 0.34; // euro/liter
    private int aantalKoeien;

    public Weiland(double oppervlakte, String referentieNummerPerceel, int aantalKoeien) {
        super(oppervlakte, referentieNummerPerceel);
        this.aantalKoeien = aantalKoeien;
    }

    public void setAantalKoeien(int aantalKoeien) {
        this.aantalKoeien = aantalKoeien;
    }

    public static void setMelkPrijs(double melkPrijs) {
        Weiland.melkPrijs = melkPrijs;
    }

    public double opbrengst() {
        double opbrengst = (aantalKoeien * HOEVEELHEID_MELK * DAGEN_PER_JAAR * melkPrijs) - (ONDERHOUDWEILAND * oppervlakte);
        return opbrengst; // euro/jaar
    }

    @Override
    public String toString() {
        return "Weiland" + super.toString() +
                "\naantal koeien = " + aantalKoeien +
                "\nopbrengst = " + opbrengst() + "\n\n";
    }
}
