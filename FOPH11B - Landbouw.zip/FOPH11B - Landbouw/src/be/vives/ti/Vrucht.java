package be.vives.ti;

public enum Vrucht {
    AARDAPPELEN("aardappelen",10200),
    RODE_KOOL("rode kool",11900),
    PREI("prei",14500),
    BLOEMKOOL("bloemkool",13200),
    TARWE("tarwe", 18300),
    BIETEN("bieten",9800);

    private final String vrucht;
    private final double coefficient;

    Vrucht(String vrucht, double coefficient) {
        this.vrucht = vrucht;
        this.coefficient = coefficient;
    }

    public String getVrucht() {
        return vrucht;
    }

    public double getCoefficient() {
        return coefficient;
    }
}
