package be.vives.ti;

public class Perceel implements Comparable<Perceel> {
    protected final double oppervlakte; // hectare
    protected final String referentieNummerPerceel;

    public Perceel(double oppervlakte, String referentieNummerPerceel) {
        this.oppervlakte = oppervlakte;
        this.referentieNummerPerceel = referentieNummerPerceel;
    }

    public String getReferentieNummerPerceel() {
        return referentieNummerPerceel;
    }

    @Override
    public String toString() {
        return "\nreferentieNummerPerceel = " + referentieNummerPerceel + "\noppervlakte = " + oppervlakte;
    }

    public double opbrengst() {
        return 0.0;
    }

    @Override
    public int compareTo(Perceel o) {
        if (this.opbrengst() < o.opbrengst()) {
            return -1;
        }
        if (this.opbrengst() > o.opbrengst()) {
            return 1;
        }
        else {
            return 0;
        }
    }
}
