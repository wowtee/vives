package be.vives.ti;

public class Akker extends Perceel{
    private Vrucht vrucht;

    public Akker(double oppervlakte, String referentieNummerPerceel, Vrucht vrucht) {
        super(oppervlakte, referentieNummerPerceel);
        this.vrucht = vrucht;
    }

    public double opbrengst() {
        double opbrengst = oppervlakte * vrucht.getCoefficient();
        return opbrengst;
    }

    @Override
    public String toString() {
        return "Akker" + super.toString() +
                "\nvrucht = " + vrucht.getVrucht() +
                "\nopbrengst = " + opbrengst() + "\n\n";
    }
}
