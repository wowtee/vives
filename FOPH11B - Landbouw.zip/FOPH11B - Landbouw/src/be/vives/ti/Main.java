package be.vives.ti;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        LandbouwBedrijf lb1 = new LandbouwBedrijf(1, "Jan Janssen", "Antwerpen");
        Akker akker1 = new Akker(10, "a1", Vrucht.AARDAPPELEN);
        Akker akker2 = new Akker(15, "a2", Vrucht.TARWE);
        Akker akker3 = new Akker(7, "a3", Vrucht.RODE_KOOL);
        Weiland weiland1 = new Weiland(17, "w4", 21);

        lb1.addPerceel(akker1);
        lb1.addPerceel(akker2);
        lb1.addPerceel(akker3);
        lb1.addPerceel(weiland1);

        System.out.println(akker1.opbrengst());
        System.out.println(weiland1.opbrengst());
        System.out.println("------");
        System.out.println(akker1);
        System.out.println("------");
        System.out.println(weiland1);
        System.out.println("------");
        System.out.println();
        System.out.println();
        System.out.println(lb1.toString());
    }
}
