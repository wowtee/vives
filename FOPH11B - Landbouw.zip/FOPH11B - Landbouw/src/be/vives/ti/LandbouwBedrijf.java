package be.vives.ti;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class LandbouwBedrijf {
    private final int referentieNummer;
    private String naamBedrijfsvoerder;
    private String adres;
    private ArrayList<Perceel> percelen;

    public LandbouwBedrijf(int referentieNummer, String naamBedrijfsvoerder, String adres) {
        this.referentieNummer = referentieNummer;
        this.naamBedrijfsvoerder = naamBedrijfsvoerder;
        this.adres = adres;
        percelen = new ArrayList<>();
    }

    public void addPerceel(Perceel perceel) {
        percelen.add(perceel);
    }

    public void removePerceel(String referentieNummerPerceel) {
        Iterator<Perceel> it = percelen.iterator();
        while (it.hasNext()) {
            Perceel perceel = it.next();
            if (perceel.getReferentieNummerPerceel().equals(referentieNummerPerceel)) {
                it.remove();
            }
        }
    }

    public void removePerceel(Perceel perceel) {
        percelen.remove(perceel);
    }

    public ArrayList<Perceel> sorteerPercelen() {
        Collections.sort(percelen);
        return percelen;
    }

    public double opbrengstLandbouwbedrijf() {
        double opbrengst = 0;
        for (Perceel perceel : percelen) {
            opbrengst += perceel.opbrengst();
        }
        return opbrengst;
    }

    @Override
    public String toString() {
        Collections.sort(percelen);
        String output = "LandbouwBedrijf met referentieNummer=" + referentieNummer +
                "\nnaamBedrijfsvoerder = " + naamBedrijfsvoerder +
                "\nadres = " + adres + "\n\n";
        for (Perceel p : percelen) {
            output += p.toString();
        }
        output += "\nDe totale opbrengst van dit jaar is " + this.opbrengstLandbouwbedrijf() + "\n====================\n";
        return output;
    }
}